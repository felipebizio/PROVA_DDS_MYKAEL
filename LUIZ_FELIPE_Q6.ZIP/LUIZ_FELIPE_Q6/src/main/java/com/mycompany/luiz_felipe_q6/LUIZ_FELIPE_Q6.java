/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.luiz_felipe_q6;

import java.util.Scanner;

/**
 *
 * @author lbizio
 */
public class LUIZ_FELIPE_Q6 {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        float media;
        int n1, n2, soma;
                
                
        System.out.println("Digite um numero: ");
        n1 = ler.nextInt();
        
        System.out.println("Digite outro numero: ");
        n2 = ler.nextInt();
        
        media = ((n1+n2)/2);
        soma = n1 + n2;
        
        System.out.println("A média é: "+ media);
        System.out.println("A soma é: "+ soma);
        System.out.println("Foram informados 2 valores, são eles os valores: "+ n1 + " e "+ n2);
    }
}
