/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.luiz_felipe_q5;

import java.util.Scanner;

/**
 *
 * @author lbizio
 */
public class LUIZ_FELIPE_Q5 {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        
        System.out.println("Digite o código de usuário: ");
        int codUs = ler.nextInt();
        
        if (codUs!= 1234){
            System.out.println("Usuário inválido!");
        }else if(codUs == 1234){
            System.out.println("Digite sua senha: ");
            int senha = ler.nextInt();
            
            if (senha != 9999){
                System.out.println("Senha Incorreta");
            }else {
                System.out.println("Acesso Permitido");
            }
        }

    }
}


/*Faça um algoritmo para ler um número que é um código de usuário. Caso este código seja diferente de um código armazenado
internamente no algoritmo (igual a 1234) deve ser apresentada a mensagem ‘Usuário inválido!’. Caso o Código seja correto, 
deve ser lido outro valor que é a senha. Se esta senha estiver incorreta (a certa é 9999) deve ser mostrada a mensagem ‘senha incorreta’. 
Caso a senha esteja correta, deve ser mostrada a mensagem ‘Acesso permitido’

 */