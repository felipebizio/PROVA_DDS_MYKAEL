/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.luiz_felipe_q3;

import java.util.Scanner;

/**
 *
 * @author lbizio
 */
public class LUIZ_FELIPE_Q3 {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        int cafeEx,qtdCafeEx = 0, cafeCa,qtdCafeCa = 0, LeiteC, qtdLeiteC = 0;
        
        for (int i= 0; i <=100; i++){
            System.out.println("Digite a opção desejada: ");
            System.out.println("1- Café Expresso\n 2- Café capuccino\n 3- Leite com café\n 4- Totalizar vendas");
            int esc = ler.nextInt();
            
            if(esc == 1){
                qtdCafeEx = qtdCafeEx + 1; 
                
            }else if (esc == 2){
                qtdCafeCa = qtdCafeCa + 1;
            }else if (esc == 3){
                qtdLeiteC = qtdLeiteC + 1;
            }else if (esc == 4){
                System.out.println(qtdCafeEx+ " e "+ qtdCafeEx*0.75 + " de café expresso vendido");
                System.out.println(qtdCafeCa+ " e "+ qtdCafeCa*1+ " de café capuccino vendido");
                System.out.println(qtdLeiteC+ " e "+ qtdLeiteC*1.25+ " de leite com café vendido" );
                System.out.println((qtdCafeEx + qtdCafeCa + qtdLeiteC)+ " e "+ ((qtdCafeEx*0.75)+ (qtdCafeCa*1)+ (qtdLeiteC*1.25))+
                        " de todos cafés vendidos");
                break;
            }
        }
    }
}

 /*
• quantidade e valor de café capuccino vendido;

• quantidade e valor de leite com café vendido;

• quantidade e valor de todos cafés vendidos;*/