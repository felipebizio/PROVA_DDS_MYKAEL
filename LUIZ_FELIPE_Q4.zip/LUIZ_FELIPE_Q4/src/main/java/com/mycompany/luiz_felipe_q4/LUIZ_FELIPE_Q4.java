/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.luiz_felipe_q4;

import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author lbizio
 */
public class LUIZ_FELIPE_Q4 {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        
        int n1;
        String n = JOptionPane.showInputDialog(null,"Digite um número inteiro: "); 
        n1 = Integer.parseInt(n); 
        
        JOptionPane.showMessageDialog(null,"O antecessor é: "+ (n1-1)+ " e seu sucessor é: "+ (n1+1));


    }
}
