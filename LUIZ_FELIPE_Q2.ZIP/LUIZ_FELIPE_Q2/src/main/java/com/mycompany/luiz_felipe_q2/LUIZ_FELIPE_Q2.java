/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.luiz_felipe_q2;

import java.io.DataInputStream;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author lbizio
 */
public class LUIZ_FELIPE_Q2 {

    private static int i;
    private static String s;

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        
        int dia, mesess, meses, anoss, anos, soma;
                
                
        System.out.println("Digite quantos anos: ");
        anos = ler.nextInt();
        
        System.out.println("Digite quantos meses: ");
        meses = ler.nextInt();
        
        System.out.println("Digite quantos dias: ");
        dia = ler.nextInt();
        
        anoss = anos*365;
        mesess = meses*30;
        soma = anoss+mesess+dia;
                
        System.out.println(anos+" anos, "+meses+" meses, "+dia+" dias = "+soma+ " dias.");     
        /*System.out.println("A média é: " );
        System.out.println("A soma é: ");
        System.out.println("Foram informados 2 valores");*/
    }
    
}









//Construa um algoritmo para ler um número N informado pelo usuário, ao final deverá ser calculado a média, soma e a quantidade dos valores digitados.























/* FileWriter arquivo = new FileWriter("\\"".txt"); 
PrintWriter arquivoTxt = new PrintWriter(arquivo); 
arquivoTxt.println(""); arquivo.close(); 
String n = JOptionPane.showInputDialog(null,""); 
f = Double.parseDouble(n); 
JOptionPane.showMessageDialog(null,"");
for (int i = 0; i < 3; i++) switch (n){ case 1: DataInputStream dado; 
System.out.println(""); 
dado = new DataInputStream(System.in);
s = dado.readLine(); 
vF = Float.parseFloat(s); 



Declarar um vetor
int[] vetor = new int[qtd];

//Declarar uma matriz
int[][] matriz = new int[linha][colunas]; 
int[][] matriz = {{1,1,1},{2,2,2},{3,3,3}};

//Criar um arquivo txt
FileWriter arquivo = new FileWriter(local + "\\" + nome + ".txt"); 
PrintWriter escrever = new PrintWriter(arquivo);
arquivo.close();

//JOptionsPane 
JOptionPane.showMessageDialog(null,"Mensagem"); 
JOptionPane.showInputDialog(mensagem); 

//Criar um DataInput DataInputStream dado;
dado = new DataInputStream(System.in); 
s = dado.readLine() notas[i] = Float.parseFloat(s);*/




